package com.example.motion_game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //Sensor and sensor manager objects
    private SensorManager sensorManager;

    /*
    Boolean to be set true if we are awaiting a new move, i.e green checkmark
    Stops the Sensor event from giving a new direction until set timer finishes.
    Gives the user time to see they have completed a move
    */
    private boolean waiting = false;
    //Set false when there is not game being played
    private boolean playing = false;

    //String to hold the next move
    private String next = "Down";
    private int nextIndex = 0;

    //The options for directions we can use for next move
    private final String[] directions = {"Down" , "Left" , "Up" , "Right" , "Toward" , "Away"};

    private final String newBoard = "Score : 0";

    private int score = 0;
    private int clock = 0;

    private long interval = 10000;

    private CountDownTimer countDown;

    //View elements
    private ImageView output;
    private TextView scoreBoard;
    private TextView timer;
    private Spinner difficulty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor mAccel = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);

        output = findViewById(R.id.imageView);
        scoreBoard = findViewById(R.id.scoreBoard);
        difficulty = findViewById(R.id.difficulty);
        timer = findViewById(R.id.clock);

        output.setImageResource(R.drawable.game_over);
        //scoreBoard.setText("Score : " + String.valueOf(score));
        //array adapter for the spinner menu
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this , R.array.difficulties , android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        difficulty.setAdapter(adapter);
        difficulty.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String newDifficulty = adapterView.getItemAtPosition(i).toString();



                switch (newDifficulty) {
                    case "Easy" :
                        interval = 8000;
                        break;
                    case "Medium" :
                        interval = 5000;
                        break;
                    case "Hard" :
                        interval = 3000;
                        break;
                }

            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        output.setOnClickListener(view -> {
            if ((!playing) && (!waiting)) {
                newDirection();
                startTimer();
                scoreBoard.setText(newBoard);
                score = 0;
                playing = true;
            }
        });

        SensorEventListener sensorEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                String nextMove = next;

                if ((sensorEvent!=null) && (!waiting) && (playing)) {
                    boolean moveMade = false;

                    float x = sensorEvent.values[0];
                    float y = sensorEvent.values[1];
                    float z = sensorEvent.values[2];

                    if ((x > 3) && (nextMove.equals("Left"))) {
                        output.setImageResource(R.drawable.check);
                        output.setRotation(0);
                        moveMade = true;
                    }
                    else if ((x < -3) && (nextMove.equals("Right"))) {
                        output.setImageResource(R.drawable.check);
                        output.setRotation(0);
                        moveMade = true;
                    }
                    else if ((y > 3) && (nextMove.equals("Down"))){
                        output.setImageResource(R.drawable.check);
                        output.setRotation(0);
                        moveMade = true;
                    }
                    else if ((y < -3) && (nextMove.equals("Up"))){
                        output.setImageResource(R.drawable.check);
                        output.setRotation(0);
                        moveMade = true;
                    }
                    else if ((z < -3) && (nextMove.equals("Toward"))){
                        output.setImageResource(R.drawable.check);
                        moveMade = true;
                    }
                    else if ((z > 3) && (nextMove.equals("Away"))){
                        output.setImageResource(R.drawable.check);
                        moveMade = true;
                    }
                    if (moveMade) {
                        /*
                        by setting waiting to true, we prevent the event listener from doing anything
                        with the acceleration data while the green checkmark appears.
                        After the interval is complete,
                        set a new direction and start checking linear acceleration again
                        */
                        //stop the game timer
                        stopTimer();
                        waiting = true;
                        score++;
                        //Update the score in the view
                        String newTxt = "Score : " + score;
                        scoreBoard.setText(newTxt);
                        //timer to pause the game when the player has made a move
                        new CountDownTimer(1000 , 1000) {
                            @Override
                            public void onFinish() {
                                newDirection();
                                startTimer();
                                waiting = false;
                            }
                            @Override
                            public void onTick(long l) {

                            }
                        }.start();
                    }
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        };

        sensorManager.registerListener(sensorEventListener, mAccel, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void startTimer () {
        clock = (int) interval / 1000;

        countDown = new CountDownTimer(interval , 1000) {
            @Override
            public void onTick(long l) {
                timer.setText(Integer.toString(clock));
                clock--;
            }

            @Override
            public void onFinish() {
                output.setImageResource(R.drawable.game_over);
                timer.setText("");
                output.setRotation(0);
                playing = false;
                waiting = false;
            }
        };
        countDown.start();
    }
    public void stopTimer() {
        countDown.cancel();
    }


    public void newDirection() {
        //Using math.random to select the next option from our Array of movement options.
        int rand = (int)(Math.random() * 6);
        //Catch a duplicate direction, never have 2 same directions in a row
        if (rand == nextIndex) {
            //if we are at the max value of the array, take the first element.
            if (rand == 5) {
                rand = 0;
            }
            else {
                rand =  rand + 1;
            }
        }
        nextIndex = rand;
        //put the next direction chosen into our member variable
        next = directions[rand];
        if (rand < 4) {
            /* if the next move is in the x or y plane, we use our simple arrow image and rotation
            to make it appear the arrow is pointing in the correct direction
            this way we only need one image for x,y planes in drawable */
            float imageAngle = (float) rand * 90;

            output.setImageResource(R.drawable.arrow);
            //set the rotation of the image
            output.setRotation(imageAngle);
        }
        else if (rand == 4) {
            output.setImageResource(R.drawable.toward_arrow);
        }
        else if (rand == 5) {
            output.setImageResource(R.drawable.away_arrow);
        }

    }
}